#include <stdio.h>

int main() {

    int gerentes = 0, trabajadoresHorario = 0, trabajadoresComision = 0;
    float montoTotal = 0.0;
    float montoGerentes = 0.0, montoTrabajadoresHorario = 0.0, montoTrabajadoresComision = 0.0;

    float salarioGerente = 1380.57;
    float salarioHorarioBase = 560.84;
    float valorHoraExtra = 1.5 * salarioHorarioBase;
    float salarioComisionBase = 425.99;
    float porcentajeVentas = 0.046;

    char opcion;

    do {
        printf("\nSeleccione el tipo de empleado:\n");
        printf("1. Gerente\n");
        printf("2. Trabajador con Horario\n");
        printf("3. Trabajador a Comisión\n");
        printf("Ingrese la opción: ");
        scanf(" %c", &opcion);

        float horasTrabajo = 0, ventas = 0, salarioMensual = 0;

        switch(opcion) {
            case '1':
                gerentes++;
                salarioMensual = salarioGerente;
                montoGerentes += salarioMensual;
                break;
            case '2':
                trabajadoresHorario++;
                printf("Ingrese las horas trabajadas: ");
                scanf("%f", &horasTrabajo);

                if (horasTrabajo > 40) {
                    salarioMensual = salarioHorarioBase + (horasTrabajo - 40) * valorHoraExtra;
                } else {
                    salarioMensual = salarioHorarioBase;
                }
                montoTrabajadoresHorario += salarioMensual;
                break;
            case '3':
                trabajadoresComision++;
                printf("Ingrese las ventas realizadas: ");
                scanf("%f", &ventas);
                salarioMensual = salarioComisionBase + porcentajeVentas * ventas;
                montoTrabajadoresComision += salarioMensual;
                break;
            default:
                printf("Opción no válida. Inténtelo de nuevo.\n");
                continue;
        }

        montoTotal += salarioMensual;

        char respuesta;
        do {
            printf("¿Desea calcular el salario de otro empleado? (S/N): ");
            scanf(" %c", &respuesta);

            if (respuesta != 'S' && respuesta != 's' && respuesta != 'N' && respuesta != 'n') {
                printf("Opción no válida. Digite S/N.\n");
            }

        } while (respuesta != 'S' && respuesta != 's' && respuesta != 'N' && respuesta != 'n');

        if (respuesta == 'N' || respuesta == 'n') {
            break;
        }

    } while (1);

    printf("\nResumen de Nómina:\n");
    printf("Gerentes: %d (Monto: %.2f dólares, Porcentaje: %.2f%%)\n", gerentes, montoGerentes, (montoGerentes / montoTotal) * 100);
    printf("Trabajadores con Horario: %d (Monto: %.2f dólares, Porcentaje: %.2f%%)\n", trabajadoresHorario, montoTrabajadoresHorario, (montoTrabajadoresHorario / montoTotal) * 100);
    printf("Trabajadores a Comisión: %d (Monto: %.2f dólares, Porcentaje: %.2f%%)\n", trabajadoresComision, montoTrabajadoresComision, (montoTrabajadoresComision / montoTotal) * 100);
    printf("Monto Total Mensual: %.2f dólares\n", montoTotal);

    return 0;
}
